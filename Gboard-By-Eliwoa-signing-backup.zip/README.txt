Signing backup for Gboard By Eliwoa (com.gboard.eli).

eliwoa.jks is the exact keystore used for the published APK.
Key alias: eliwoa
keystore-password.txt contains its password; keep both files private.
Public signing certificate SHA-256:
835CFD33F94E1CC744655D3E48ABDCD0F56C8F0865AA09C5AEC830B5CE51E233

Retain this key to sign updates for your existing installation.
Do not upload this backup to a public repository or share its password.
